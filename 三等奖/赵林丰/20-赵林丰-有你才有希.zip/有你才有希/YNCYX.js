window.onload = function () {
  let Btn = document.getElementsByTagName('button');
  Btn.onmousemove = changeC();
  function changC() {
      Btn.style.background = "pink";
  }
}
