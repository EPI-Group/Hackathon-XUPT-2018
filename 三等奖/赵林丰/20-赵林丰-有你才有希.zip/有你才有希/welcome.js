window.onload = function () {
    let onClicks = document.getElementById('onClick');
    let rightTalks = document.getElementById('rightTalk');
    let words = document.getElementById('word');
    let num = 0;


    onClicks.onclick = function () {
      qingqiu();
    };

    function qingqiu (){
        if (num === 0) {
            let talk1 = document.createElement('div');
            talk1.className = 'chat-bubble chat-bubble-right' ;
            let pic = document.createElement('img');
        pic.className = 'photo2';
        pic.src = 'C:/Users/jia/Desktop/puc/ab.jpg';

        rightTalks.appendChild(talk1);
        rightTalks.appendChild(pic);
        talk1.innerText = '没有！这是干嘛的？';

        let talk2 = document.createElement('div');
        talk2.className = 'chat-bubble chat-bubble-left';

        let pic1 = document.createElement('img');
        pic1.className = 'photo1';
        pic1.src = 'http://img.hb.aicdn.com/319dd7d958bd492a920a3d871503f36d39f4d0bd13ebeb-np1bzz_fw658';
        rightTalks.appendChild(pic1);
        rightTalks.appendChild(talk2);
        talk2.innerText = '这是一个校园服务平台，主要有三大功能：失物招领，废旧物品回收！我们希望为学校尽一点自己的绵薄之力'


        //3.1删除节点
        words.innerText = "哎呦！这个想法不错，值得表扬，以后不光要让我的学生们早上六点去读书，还要让他们到我办公室喝茶看这个网站";

        num = 1;
    }
        else if(num === 1){
            //3、当点击之后触发的时间

                //2、1 创建气泡
                let talk3 = document.createElement('div');
                talk3.className = 'chat-bubble chat-bubble-right' ;
                //2、2 创建图片
                let pic = document.createElement('img');
                pic.className = 'photo2';
                pic.src = 'C:/Users/jia/Desktop/puc/ab.jpg';

                rightTalks.appendChild(talk3);
                rightTalks.appendChild(pic);
                talk3.innerText = '哎呦！这个想法不错，值得表扬，以后不光要让我的学生们早上六点去读书，还要让他们到我办公室喝茶看这个网站';

                //2.3 创建回答气泡
                let talk4 = document.createElement('div');
                talk4.className = 'chat-bubble chat-bubble-left';

                //2.4 图片
                let pic1 = document.createElement('img');
                pic1.className = 'photo1';
                pic1.src = 'http://img.hb.aicdn.com/319dd7d958bd492a920a3d871503f36d39f4d0bd13ebeb-np1bzz_fw658';
                rightTalks.appendChild(pic1);
                rightTalks.appendChild(talk4);
                talk4.innerText = '老师，老师，我不是这个意思';

                //3.1删除节点
                words.innerText = "好了！就这么说定了";

                onClicks.onclick = null;

        }
}

}