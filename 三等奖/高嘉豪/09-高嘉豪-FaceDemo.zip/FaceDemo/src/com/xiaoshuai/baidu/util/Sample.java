package com.xiaoshuai.baidu.util;

import java.io.IOException;
import java.util.HashMap;
import org.json.JSONObject;
import com.baidu.aip.face.AipFace;
import com.baidu.aip.http.AipRequest;
import com.baidu.aip.util.Base64Util;

public class Sample {
    	 public static void main(String[] args) throws IOException {
    		//��ʼ��һ��FaceClient
    	 		AipFace face = new AipFace("15078971", "ZsrTFmwuav3jApgfwSNiriVf", "zeqTFPvVcQMsPvalnL3uf2RyzZ1lYeOU");
    	 		//��ѡ�������������Ӳ���
    	 		face.setConnectionTimeoutInMillis(60000);
    	 		face.setSocketTimeoutInMillis(60000);
    	 		//����API
    	 		HashMap map = new HashMap();
    	 		map.put("face_field", "age,beauty,gender,expression,race,quality,facetype,glasses");
    	 	    map.put("max_face_num", "2");
    	 	    map.put("face_type", "LIVE");
    	 		String Filepath = "E:\\ceshi.jpg";
    			String image = Base64Util.encode(FileUtil.readFileByBytes(Filepath));
    	 		String imageType = "BASE64";
    	 		AipRequest aipRequest = new AipRequest();
    	 		aipRequest.setBody(map);
    	 		JSONObject result = face.detect(image,imageType,map);
    	 		System.out.println(result.toString(2));
		}
 }
