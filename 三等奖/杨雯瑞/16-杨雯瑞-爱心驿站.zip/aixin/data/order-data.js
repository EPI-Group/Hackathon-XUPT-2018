var order_data=[{
 Image:"/images/close.png",
  name:"衣物",
  orderId:0,
  url: "order-cloth/order-cloth"
},
{
  Image: "/images/j.jpg",
  name:"裤子",
  orderId: 1,
  url: "order-trousers/order-trousers"
},
{
  Image: "/images/shoe.jpg",
  name:"鞋子",
  orderId: 2,
  url: "order-shoes/order-shoes"
},
{
  Image: "/images/back2.png",
  name:"包包",
  orderId: 3,
  url: "order-bags/order-bags"
},
  {
    Image: "/images/yuedu2.jpg",
     name:"书籍",
    orderId: 4,
    url: "order-books/order-books"
  },
  {
    Image: "/images/other.jpg",
    name:"其他",
    orderId: 5,
    url: "order-others/order-others"
  }
]
module.exports={
  orderPage: order_data,
}