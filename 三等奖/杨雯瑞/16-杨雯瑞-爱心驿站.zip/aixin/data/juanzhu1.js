var juanzhu_data = [
  {
    wupin: "/images/3.png",
    wuming: "夹克",
    dateTime: "24小时前",
    juanzhuId: 0,
  },
  {

    wupin: "/images/3.png",
    wuming: "夹克",
    dateTime: "24小时前",
    juanzhuId: 1,
  },
  {

    wupin: "/images/3.png",
    wuming: "夹克",
    dateTime: "24小时前",
    juanzhuId: 2,
  },
]
module.exports = {
  juanzhu: juanzhu_data
}