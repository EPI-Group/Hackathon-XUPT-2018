项目简介
=====

# 团队成员介绍
* 刘 安全1804
* 泮 通工1515

-------


# 联系方式

* QQ : 1799226537


server
----------
这一部分完全采用纯jdk的功能实现，基于jdk.7

### com.mec.connector 
连接器部分
* com.mec.connector.http 
提供基于http协议的封装，用于构造、解析http请求、响应

* Processor 连接器的处理器部分，用于处理http连接请求

* Processors Processor集合，内置自己实现的线程池用于响应http连接请求

### com.mec.container
* 容器部分，这部分实现了Context、wrapper等容器

* com.mec.container.filter 用于实现filter链的功能，通过web.xml配置，并在wrapper的standardValve中加载

* com.mec.container.loaders 扩展了ClassLoader

* com.mec.container.session 实现了session功能


### com.mec.pymont.interface
* 接口

### com.mec.startup
* com.mec.startup.Bootstrap 全流程的启动器，以后将使用 .bat 或者 .sh的方式启动，并将配置关系通过配置文件来走

### com.mec.util
* 工具类，里面具体提供了xml解析器，便于读web.xml等xml文件


rpc
----------
这部分由于底层采用netty、基于jdk8

### rpc-client
客户端
* com.rpc.client.loadBalance 负载均衡功能

* com.rpc.client.proxy 代理

* com.rpc.client.service 服务

### rpc-common
提供公共部分

### rpc-parent
暂时空的

### rpc-server
服务器


more
----------
接下来的事情

* 流量监控
* 配置中心、注册中心
* ui界面

以上功能均可以通过tomcat的pipline中的valve集成进去，亦或者通过rpc集成，当然现在整个项目处于初始阶段，若需要继续，整体需要多次重构。

目前来说，最大的帮助是供大家学习与参考。
