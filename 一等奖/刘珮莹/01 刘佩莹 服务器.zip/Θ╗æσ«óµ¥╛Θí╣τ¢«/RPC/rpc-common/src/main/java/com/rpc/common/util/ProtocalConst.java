package com.rpc.common.util;

public class ProtocalConst {
	public static final Integer SESSION_ID_LENGTH = 5;
	public static final String ROOT = "/rpc";
	public static final String SERVICE_LIST = ROOT + "/services";
}
