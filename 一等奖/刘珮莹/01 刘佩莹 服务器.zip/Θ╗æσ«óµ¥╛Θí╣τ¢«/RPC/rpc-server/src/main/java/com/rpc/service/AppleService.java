package com.rpc.service;

public interface AppleService {
	public String eat(String name); 
	public String drink();
}
