package com.rpc.service;

public interface UserService {
	String sayHello(String name);
}
