package com.rpc.service.Impl;

import com.rpc.service.AppleService;

public class AppleServiceImpl implements AppleService{

	@Override
	public String eat(String name) {
		// TODO Auto-generated method stub
		return "吃苹果";
	}

	@Override
	public String drink() {
		// TODO Auto-generated method stub
		return "喝水";
	}
	
}
