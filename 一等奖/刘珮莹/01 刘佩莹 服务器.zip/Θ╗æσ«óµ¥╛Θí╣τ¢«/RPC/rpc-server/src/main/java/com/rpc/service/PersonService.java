package com.rpc.service;

import com.rpc.client.pojo.Person;

public interface PersonService {
	void say(Person person);
}
