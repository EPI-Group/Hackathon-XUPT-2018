package com.rpc.client.exception;

public class NotFoundServiceException extends Exception {

	public NotFoundServiceException(String message) {
		super(message);
	}

}
