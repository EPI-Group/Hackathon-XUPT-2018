package com.rpc.client.exception;

public class NotFoundMethodException extends Exception {
	public NotFoundMethodException(String message) {
		super(message);
	}
}
