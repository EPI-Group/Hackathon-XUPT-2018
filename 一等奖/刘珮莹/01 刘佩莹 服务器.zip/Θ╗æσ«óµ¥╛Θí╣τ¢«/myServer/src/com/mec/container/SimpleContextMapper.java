package com.mec.container;

import com.mec.connector.http.HttpRequest;
import com.mec.pymont.interfaces.Container;
import com.mec.pymont.interfaces.Mapper;
import com.mec.pymont.interfaces.Wrapper;


public class SimpleContextMapper implements Mapper{

	private SimpleContext context = null;
	private String protocol = null;

	@Override
	public Container getContainer() {
		return context;
	}

	@Override
	public String getProtocol() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setContainer(Container container) {
		// TODO Auto-generated method stub
		if (!(container instanceof SimpleContext))
			throw new IllegalArgumentException
	        ("Illegal type of container");
		context = (SimpleContext) container;
	}

	@Override
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	@Override
	public Container map(HttpRequest request, boolean update) {
		// TODO Auto-generated method stub
		if (update && request.getWrapper() != null) {
			return request.getWrapper();
		}
		
		String contextPath = request.getContextPath();
		String requestURI = request.getRequestURI();
		String relativeURI = requestURI.substring(contextPath.length());
		
		Wrapper wrapper = null;
		String servletPath = relativeURI;
		String pathInfo = null;
		System.out.println(servletPath);
		String name = context.findServletMapping(servletPath);
		if (name != null) {
			wrapper = (Wrapper) context.findChild(name);
			System.out.println(wrapper+"]wrapper");
		}
		
		if (update) {
			request.setWrapper(wrapper);
		}
		
		return wrapper;
	}
	
	
}
