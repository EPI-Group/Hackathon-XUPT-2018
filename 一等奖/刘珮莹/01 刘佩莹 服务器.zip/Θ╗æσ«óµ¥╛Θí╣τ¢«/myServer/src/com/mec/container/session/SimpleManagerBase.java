package com.mec.container.session;

import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.catalina.Container;
import org.apache.catalina.DefaultContext;
import org.apache.catalina.Session;

import com.mec.pymont.interfaces.Context;
import com.mec.pymont.interfaces.MyManager;

public class SimpleManagerBase implements MyManager{
	
	public final static int maxInactiveInterval = 5;
	private Context context = null;
	protected Map<String, Session> sessions = new ConcurrentHashMap<String, Session>();
	protected int sessionCounter = 0;
	
	private int duplicates = 0;
	@Override
	public void add(Session session) {
		// TODO Auto-generated method stub
		synchronized(sessions) {
			sessions.put(session.getId(), session);
		}
	}

	@Override
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Session createEmptySession() {
		// TODO Auto-generated method stub
		System.out.println("���ӿյ�session");
		return new MySession(this);
	}

	@Override
	public Session createSession(String sessionId) {
		// TODO Auto-generated method stub
		Session session = createEmptySession();
		
		session.setNew(true);
		session.setValid(true);
		session.setCreationTime(System.currentTimeMillis());
		session.setMaxInactiveInterval(this.maxInactiveInterval);
		
		String id = sessionId;
		if (id == null) {
			id = generateSessionId();
		}
		session.setId(sessionId);
		sessionCounter++;
		//TODO
		add(session);
		
		return session;
	}

	protected String generateSessionId() {
		// TODO Auto-generated method stub
		String result = null;
		SessionIdGenerator gernerator = new SessionIdGenerator();
		do {
			if (result != null) {
				duplicates++;
			}
			
			result = gernerator.generateSessionId();
			
		} while (sessions.containsKey(result));
		
		return result;
	}

	@Override
	public Session findSession(String sessionId) {
		// TODO Auto-generated method stub
		if (sessionId == null) {
			return null;
		}
		synchronized(sessions) {
			Session session = (Session) sessions.get(sessionId);
			return session;
		}
	}

	@Override
	public Session[] findSessions() {
		Session results[] = null;
		synchronized(sessions) {
			results = new Session[sessions.size()];
			results = (Session[]) sessions.values().toArray(results);
			return results;
		}
	}

	@Override
	public Container getContainer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DefaultContext getDefaultContext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean getDistributable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getMaxInactiveInterval() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void load() throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remove(Session session) {
		synchronized(sessions) {
			sessions.remove(session.getId());
		}
	}

	@Override
	public void removePropertyChangeListener(PropertyChangeListener listener) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setContainer(Container container) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDefaultContext(DefaultContext context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDistributable(boolean arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setMaxInactiveInterval(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void unload() throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Session createSession() {
		return createSession(null);
	}

}
