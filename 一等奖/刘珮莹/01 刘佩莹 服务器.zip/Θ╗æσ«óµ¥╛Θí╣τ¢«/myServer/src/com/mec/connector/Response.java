package com.mec.connector;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;


public class Response {
	int BUFFER_SIZE = 2048;
	private Request request;
	private OutputStream output;
	
	public Response(Request request, OutputStream output) {
		this.request = request;
		this.output = output;
	}
	
	public void sendStaticResource() {
		try {
			byte[] buffer = new byte[2 * 1024];
			File file = new File(Connector.WEB_ROOT, request.getUri());
			FileInputStream fips = new FileInputStream(file);
			
			int len =fips.read(buffer, 0, 2 * 1024);
			while(len != -1) {
				output.write(buffer, 0, len);
				len = fips.read(buffer, 0, 2 * 1024);
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
