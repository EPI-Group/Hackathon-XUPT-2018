package com.mec.container;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;
import com.mec.container.filter.ApplicationFilterChain;
import com.mec.container.filter.ApplicationFilterConfig;
import com.mec.container.filter.FilterDef;
import com.mec.container.filter.FilterMap;
import com.mec.pymont.interfaces.Contained;
import com.mec.pymont.interfaces.Container;
import com.mec.pymont.interfaces.Context;
import com.mec.pymont.interfaces.Valve;
import com.mec.pymont.interfaces.ValveContext;
import com.mec.pymont.interfaces.Wrapper;
import com.mec.util.XMLReader;

public class SimpleContextValve implements Valve, Contained{

	protected Container container;
	
	@Override
	public String getInfo() {
		return "this is SimpleContextValve";
	}

	@Override
	public void invoke(HttpRequest request, HttpResponse response, ValveContext valveContext) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("------context valve invoke...");
		if (!(request instanceof HttpServletRequest) ||
				!(response instanceof HttpServletResponse))
			return;
		System.out.println(request.getRequestURI()+"-------------");
		
		if (!isVisitServlet(request.getRequestURI())) {
			try {
				doAllFilter(request, response);
				response.sendStaticResource();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return;
		}
		
		HttpServletRequest hreq = (HttpServletRequest) request;
		String contextPath = hreq.getContextPath();
		String requestURI = ((HttpRequest) request).getRequestURI();
	    String relativeURI =
	    requestURI.substring(contextPath.length()).toUpperCase();
	    
	    Context context = (Context) getContainer();

	    Wrapper wrapper = null;
	    try {
	    	  wrapper = (Wrapper) context.map(request, true);
	  	}
	  	catch (IllegalArgumentException e) {
	  	  badRequest(requestURI, (HttpServletResponse) response);
	  	  return;
	  	}
	  	if (wrapper == null) {
	  	  notFound(requestURI, (HttpServletResponse) response);
	  	  return;
	  	}
	  	response.setContext(context);
    	wrapper.invoke(request, response);
	}
	
	private void doAllFilter(HttpRequest request, HttpResponse response) {
		// TODO Auto-generated method stub
		System.out.println("in /* do html Filter");
		ApplicationFilterChain chain = creatAllFilterChain();
		try {
			chain.doFilter(request, response);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}
	
	private ApplicationFilterChain creatAllFilterChain() {
		ApplicationFilterChain chain = null;
		ArrayList<FilterDef> filterDefList = new ArrayList<>();
		HashMap<String, FilterMap> filterMap = new HashMap<String, FilterMap>();
		ArrayList<Filter> filterList = new ArrayList<>();
		XMLReader.parseFiltersMaps(filterDefList, filterMap);
		for(int i = 0; i < filterDefList.size(); i++) {
			if (trueAllFilter(filterMap, filterDefList.get(i))) {
				ApplicationFilterConfig config = 
						new ApplicationFilterConfig(((Context)container), filterDefList.get(i));
				Filter filter = config.getFilter();
				if (filter != null) {
					filterList.add(filter);
				}
			}
		}
		chain = new ApplicationFilterChain(filterList);
		return chain;
	}

	//  /*�ɹ���html����
	private boolean trueAllFilter(HashMap<String, FilterMap> filterMap, FilterDef filterDef) {
		try {
			String urlPattern = filterMap.get(filterDef.getFilterName()).getUrlPattern();
			return "/*".equals(urlPattern);
		}catch (Exception e) {
			System.out.println(filterDef.getDisplayName()+"---");
			return false;
		}
	}

	private boolean isVisitServlet(String requestURI) {
		int point = requestURI.lastIndexOf(".");
		if (point < 0) 
			return true;
		
		return false;
	}

	private void notFound(String requestURI, HttpServletResponse response) {
		try {
		      response.sendError(HttpServletResponse.SC_NOT_FOUND, requestURI);
		    }
		    catch (IllegalStateException e) {
		      ;
		    }
		    catch (IOException e) {
		      ;
		    }
	}

	private void badRequest(String requestURI, HttpServletResponse response) {
		try {
		      response.sendError(HttpServletResponse.SC_BAD_REQUEST, requestURI);
	    }
	    catch (IllegalStateException e) {
	      ;
	    }
	    catch (IOException e) {
	      ;
	    }
	}

	@Override
	public Container getContainer() {
		return container;
	}

	@Override
	public void setContainer(Container container) {
		this.container = container;
	}

}
