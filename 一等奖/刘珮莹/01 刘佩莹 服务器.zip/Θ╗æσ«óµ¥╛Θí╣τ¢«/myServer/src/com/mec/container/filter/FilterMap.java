package com.mec.container.filter;

public class FilterMap {
	private String displayName = null;
	private String urlPattern = null;
	
	public FilterMap(String displayName, String urlPattern) {
		super();
		this.displayName = displayName;
		this.urlPattern = urlPattern;
	}

	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getUrlPattern() {
		return urlPattern;
	}
	public void setUrlPattern(String urlPattern) {
		this.urlPattern = urlPattern;
	}
}
