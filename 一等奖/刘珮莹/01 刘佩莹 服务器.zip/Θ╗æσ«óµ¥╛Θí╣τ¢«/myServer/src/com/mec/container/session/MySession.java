package com.mec.container.session;

import java.security.Principal;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import org.apache.catalina.Manager;
import org.apache.catalina.Session;
import org.apache.catalina.SessionListener;

import com.mec.pymont.interfaces.Context;
import com.mec.pymont.interfaces.MyManager;

public class MySession implements Session, HttpSession{

	
	private Manager manager = null;
	private long creationTime = 0;
	private String sessionId;

	protected Map<String, Object> attributes = new ConcurrentHashMap<String, Object>();
	private transient String authType = null;
	private transient boolean expiring = false;
	private boolean isNew;
	private boolean valid = true;
	private long lastAccessedTimed = creationTime;
	
	
	public MySession(MyManager simpleManager) {
		setManager(simpleManager);
		simpleManager.add(this);
	}
	
	@Override
	public void access() {
		// TODO Auto-generated method stub
		this.lastAccessedTimed = System.currentTimeMillis();
	}

	@Override
	public void addSessionListener(SessionListener arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void expire() {
		// TODO Auto-generated method stub
		expire(true);
	}
	
	public void expire(boolean notify) {
		if (expiring)
			return;
		expiring = true;
		setValid(false);
		
		removeAttributes();
//		Context context = (Context) simpleManager.getContainer();
//		��context�õ�sessionListner�ٴ����¼�
		expiring = false;
		if ((manager != null) && manager instanceof SimpleManagerBase) {
			recycle();
		}
	}
	

	private void removeAttributes() {
		for (String key : attributes.keySet()) {
			attributes.remove(key);
		}
	}

	@Override
	public String getAuthType() {
		// TODO Auto-generated method stub
		return authType;
	}

	@Override
	public long getCreationTime() {
		// TODO Auto-generated method stub
		return creationTime;
	}

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return sessionId;
	}

	@Override
	public String getInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getLastAccessedTime() {
		// TODO Auto-generated method stub
		return lastAccessedTimed;
	}

	@Override
	public int getMaxInactiveInterval() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getNote(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator getNoteNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Principal getPrincipal() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HttpSession getSession() {
		// TODO Auto-generated method stub
		return this;
	}

	@Override
	public boolean isValid() {
		// TODO Auto-generated method stub
		if (!this.valid) {
		    return false;
		  }

		  if (this.expiring) {
		    return true;
		  }

//		  if (ACTIVITY_CHECK && accessCount.get() > 0) {
//		    return true;
//		  }
//
//		  if (maxInactiveInterval > 0) {
//		    long timeNow = System.currentTimeMillis();
//		    int timeIdle;
//		    if (LAST_ACCESS_AT_START) {
//		      timeIdle = (int) ((timeNow - lastAccessedTime) / 1000L);
//		    } else {
//		      timeIdle = (int) ((timeNow - thisAccessedTime) / 1000L);
//		    }
//		    if (timeIdle >= maxInactiveInterval) {
//		      expire(true);
//		    }
//		  }

		return valid;
	}

	@Override
	public void recycle() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeNote(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeSessionListener(SessionListener arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setAuthType(String authType) {
		// TODO Auto-generated method stub
		this.authType = authType;
	}

	@Override
	public void setCreationTime(long creationTime) {
		// TODO Auto-generated method stub
		this.creationTime = creationTime;
	}

	@Override
	public void setId(String Id) {
		// TODO Auto-generated method stub
		this.sessionId = Id;
	}

	@Override
	public void setMaxInactiveInterval(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setNew(boolean isNew) {
		// TODO Auto-generated method stub
		this.isNew = isNew;
	}

	@Override
	public void setNote(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPrincipal(Principal arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setValid(boolean valid) {
		// TODO Auto-generated method stub
		this.valid = valid;
	}

	@Override
	public Manager getManager() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setManager(Manager manager) {
		// TODO Auto-generated method stub
		this.manager = manager;
	}

	@Override
	public Object getAttribute(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Enumeration getAttributeNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServletContext getServletContext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HttpSessionContext getSessionContext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getValue(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String[] getValueNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void invalidate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return isNew;
	}

	@Override
	public void putValue(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeAttribute(String key) {
		// TODO Auto-generated method stub
		attributes.remove(key);
	}

	@Override
	public void removeValue(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setAttribute(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

}
