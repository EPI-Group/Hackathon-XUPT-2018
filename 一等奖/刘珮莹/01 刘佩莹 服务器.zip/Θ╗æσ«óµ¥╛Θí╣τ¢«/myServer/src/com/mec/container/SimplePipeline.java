package com.mec.container;

import javax.servlet.ServletException;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;
import com.mec.pymont.interfaces.Contained;
import com.mec.pymont.interfaces.Container;
import com.mec.pymont.interfaces.Pipeline;
import com.mec.pymont.interfaces.Valve;
import com.mec.pymont.interfaces.ValveContext;

public class SimplePipeline implements Pipeline{
	
	private Valve basic;
	private Container container;
	private Valve[] valves = new Valve[0];
	
	public SimplePipeline(Container container) {
		this.container = container;
	}
	
	@Override
	public Valve getBasic() {
		return basic;
	}

	@Override
	public void setBasic(Valve valve) {
		this.basic = valve;
		((Contained)valve).setContainer(container);
	}

	@Override
	public void addValve(Valve valve) {
		// TODO Auto-generated method stub
		if (valve instanceof Contained) {
			((Contained)valve).setContainer(container);
		}
		synchronized (valves) {
			Valve results[] = new Valve[valves.length + 1];
			System.arraycopy(valves, 0, results, 0, valves.length);
			results[valves.length] = valve;
			valves = results;
		}
	}

	@Override
	public Valve[] getValves() {
		return valves;
	}

	@Override
	public void invoke(HttpRequest request, HttpResponse response) throws Exception {
		// TODO Auto-generated method stub
		(new SimplePipelineValveContext()).invokeNext(request, response);
	}

	@Override
	public void removeValve(Valve valve) {
		// TODO Auto-generated method stub
		boolean meeted = false;
		synchronized (valves) {
			Valve results[] = new Valve[valves.length - 1];
			for (int i = 0; i < valves.length; i++) {
				if (!meeted) {
					results[i] = valves[i];
				} else {
					results[i-1] = valves[i];
				}
				if (valves[i].equals(valve)) {
					meeted = true;
				}
			}
		}
		
	}
	
	protected class SimplePipelineValveContext implements ValveContext {
		
		protected int index = 0;
		
		@Override
		public String getInfo() {
			return "SimplePipelineValveContext";
		}

		@Override
		public void invokeNext(HttpRequest request, HttpResponse response) throws Exception {
			int subScript = index;
			index++;
			if ((subScript == valves.length) && basic != null) {
				basic.invoke(request, response, this);
			} else if (subScript < valves.length) {
				valves[subScript].invoke(request, response, this);
			} else {
				throw new ServletException("no valve");
			}
		}
	}

}
