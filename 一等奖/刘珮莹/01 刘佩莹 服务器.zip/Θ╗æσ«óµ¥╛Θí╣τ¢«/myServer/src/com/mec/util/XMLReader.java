package com.mec.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.mec.container.filter.FilterDef;
import com.mec.container.filter.FilterMap;

public class XMLReader {

	public static void parseFiltersMaps(ArrayList<FilterDef> filterDefList, HashMap<String, FilterMap> filterMap) {
		Document document = XMLReader.parseXML("/WEB-INF/web.xml");
		NodeList filters = document.getElementsByTagName("filter");
		NodeList maps = document.getElementsByTagName("filter-mapping");
		
		XMLReader.parseFilters(filters, filterDefList);
		XMLReader.parseFilterMapping(maps, filterMap);
	}
	
	public static Document parseXML(String path) {
		Document document = null;
		try {
			InputStream is = Class.class.getResourceAsStream(path);
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			document = db.parse(is);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return document;
	}
	
	public static void parseFilters(NodeList filters, ArrayList<FilterDef> filterDefList) {
		for (int i = 0; i < filters.getLength(); i++) {
			FilterDef filterDef = new FilterDef();
			
			String displayName = null;
			String filterName = null;
			String filterClass = null;
			
			Element filter = (Element) filters.item(i);
			
			NodeList displayNames = filter.getElementsByTagName("display-name");
			if (displayNames != null && displayNames.getLength() == 1)
				displayName = ((Element)displayNames.item(0)).getTextContent();
			
			NodeList filterNames = filter.getElementsByTagName("filter-name");
			if (filterNames != null && filterNames.getLength() == 1) {
				filterName = ((Element)filterNames.item(0)).getTextContent();
			}
			
			NodeList filterClasses = filter.getElementsByTagName("filter-class");
			if (filterClasses != null && filterClasses.getLength() == 1) {
				filterClass = ((Element)filterClasses.item(0)).getTextContent();
			}
			
			filterDef.setDisplayName(displayName);
			filterDef.setFilterName(filterName);
			filterDef.setFilterClass(filterClass);
			
			NodeList initParams = filter.getElementsByTagName("init-param");
			if (initParams != null) {
				for (int j = 0; j < initParams.getLength(); j++) {
					Element initParam = (Element) initParams.item(j);
					NodeList paramNameList = initParam.getElementsByTagName("param-name");
					if (paramNameList != null && paramNameList.getLength() == 1) {
						Element paramName = (Element) paramNameList.item(0);
						String name = paramName.getTextContent();
						String value = ((Element)initParam.getElementsByTagName("param-value").item(0)).getTextContent();
						filterDef.addInitParameter(name, value);
					}
				}
			}
			
			filterDefList.add(filterDef);
		}
	}
	
	public static void parseFilterMapping(NodeList maps, HashMap<String, FilterMap> filterMapList) {
		for(int i = 0; i < maps.getLength(); i++) {
			String name = null;
			FilterMap filterMap = null;
			
			try {
				Element map = (Element) maps.item(i);
				name = ((Element)map.getElementsByTagName("filter-name").item(0)).getTextContent();
				String urlPattern = ((Element)map.getElementsByTagName("url-pattern").item(0)).getTextContent();
				filterMap = new FilterMap(name, urlPattern);
			} catch (RuntimeException e) {
				System.out.println(e.getMessage());
			}
			if (filterMap != null && name != null) {
				filterMapList.put(name, filterMap);
			}
		}
	}
	
}
