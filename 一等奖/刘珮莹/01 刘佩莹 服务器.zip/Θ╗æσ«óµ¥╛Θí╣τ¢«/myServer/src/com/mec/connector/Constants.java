package com.mec.connector;

import java.io.File;

public class Constants {
	public static final String WEB_ROOT =
			    System.getProperty("user.dir") + File.separator  + "webroot";
	public static final int PORT = 8008;
	private volatile int currCount = 0;
	private final int initCount = 4;
	private final int addCount = 2;
	private final int maxCount = 10;

}
