package com.mec.connector;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;

import org.apache.catalina.util.RequestUtil;

import com.mec.connector.http.HttpHeader;
import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpRequestLine;
import com.mec.connector.http.HttpResponse;
import com.mec.connector.http.SocketInputStream;

public class Processor implements Runnable{
	private volatile boolean available = false;
	private boolean stopped = false;
	private Connector connector = null;
	private Socket socket = null;
	private boolean ok = true;
	private HttpRequest request;
	private HttpResponse response;
	private HttpRequestLine requestLine = new HttpRequestLine();
	
	public Processor(Connector connector) {
		this.connector = connector;
	}
	
	public synchronized void assign (Socket socket) {
		while (available) {
			try {
//				System.out.println(Thread.currentThread().getName() + "assign .. wait");
				wait();
			} catch (InterruptedException e) {
			}
		}
		
		this.socket = socket;
		available = true;
//		System.out.println(Thread.currentThread().getName() + "assign..notifyAll();......");
		notifyAll();
		//TODO
	}
	
	public void process(Socket socket) {
		System.out.println(socket + "start..." + Thread.currentThread().getName());
		SocketInputStream input = null;
		OutputStream output = null;
		try {
			input = new SocketInputStream(socket.getInputStream(), 2048);
			output = socket.getOutputStream();
			
			request = new HttpRequest(input);

			response = new HttpResponse(output);
			response.setRequest(request);
			
			response.setHeader("Server", "Pyrmont Servlet Container");
			parseRequest(input, output);
			parseHeader(input);
		} catch (IOException e) {
			ok = false;
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!ok) {
			return;
		}

		connector.getContainer().invoke(request, response);

		try {
			socket.close();
		} catch (IOException e) {
		}
		System.out.println(socket + "stop..." + Thread.currentThread().getName());
	}
	
	private void parseHeader(SocketInputStream input) throws IOException, ServletException {
		
		while(true) {
			HttpHeader header = new HttpHeader();
			
			input.readHeader(header);
			if (header.nameEnd == 0)
				if (header.valueEnd == 0)
					return;
				else
					 throw new ServletException
			            ("httpProcessor.parseHeaders.colon");
			String name = new String(header.name, 0, header.nameEnd);
			String value = new String(header.value, 0, header.valueEnd);
			request.addHeader(name, value);
			
			if (name.equals("cookie")) {
				Cookie cookies[] = RequestUtil.parseCookieHeader(value);
				for(int i = 0; i < cookies.length; i++) {
					if (cookies[i].getName().equals("jsessionid")) {
						if (!request.isRequestedSessionIdFromCookie()) {
							 request.setRequestedSessionId(cookies[i].getValue());
				              request.setRequestedSessionCookie(true);
				              request.setRequestedSessionURL(false);
						} else {
							if (!request.isRequestedSessionIdValid()) {
								//replace the session id until one is valid
							}
						}
					}
					request.addCookie(cookies[i]);
				}
			} else if (name.equals("content-length")) {
				int n = -1;
				try {
					n = Integer.valueOf(value);
				} catch (Exception e) {
			        throw new ServletException("httpProcessor.parseHeaders.contentLength");
			    }
				request.setContentLength(n);
			} else if (name.equals("content-type")) {
				request.setContentType(value);
			}
		}
	}

	private void parseRequest(SocketInputStream input, OutputStream output) throws IOException, ServletException {
		input.readRequestLine(requestLine);
		String method = new String(requestLine.method, 0, requestLine.methodEnd);
		String uri = null;
		String protocol = new String(requestLine.protocol, 0, requestLine.protocolEnd);
		
		if (method.length() < 1) {
			throw new ServletException("Missing HTTP request method");
		} else if(requestLine.uriEnd < 1){
			throw new ServletException("Missing HTTP request URI");
		}
		
		int question = requestLine.indexOf("?");
		if (question >= 0) {
			request.setQueryString(new String(requestLine.uri, question + 1, 
					requestLine.uriEnd - question - 1));
			uri = new String(requestLine.uri, 0, question);
		} else {
			request.setQueryString(null);
			uri = new String(requestLine.uri, 0, requestLine.uriEnd);
		}
		
		if (!uri.startsWith("/")) {
			int pos = uri.indexOf("://");
			if (pos != -1) {
				pos = uri.indexOf("/");
				
				if (pos == -1) {
					uri = "";
				} else {
					uri = uri.substring(pos);
				}
			}
		}
		
		// Parse any requested session ID out of the request URI
		String match = ";jsessionid=";
		int semicolon = uri.indexOf(match);
		if (semicolon >= 0) {
			String rest = uri.substring(semicolon + match.length());
			int semicolon2 = rest.indexOf(";");
			if (semicolon2 > 0) {
				request.setRequestedSessionId(rest.substring(0, semicolon2));
				rest = rest.substring(semicolon2);
			} else {
				request.setRequestedSessionId(rest);
				rest = "";
			}
			request.setRequestedSessionURL(true);
			uri = uri.substring(0, semicolon) + rest;
		} else {
			request.setRequestedSessionId(null);
			request.setRequestedSessionURL(false);
		}
		// Normalize URI (using String operations at the moment)
		String normalizedUri = normalize(uri);
		
		request.setMethod(method);
		request.setProtocol(protocol);
		
		if (normalizedUri != null) {
			request.setRequestURI(normalizedUri);
		} else {
			((HttpRequest) request).setRequestURI(uri);
		}
		
		if (normalizedUri == null) {
		    throw new ServletException("Invalid URI: " + uri + "'");
		}
	} 

	private String normalize(String path) {
		if (path == null)
			return null;
		
		String normalized = path;
		
		 // Normalize "/%7E" and "/%7e" at the beginning to "/~"
	    if (normalized.startsWith("/%7E") || normalized.startsWith("/%7e"))
	    	normalized = "/~" + normalized.substring(4);
	    
	    if ((normalized.indexOf("%25") >= 0)
	      || (normalized.indexOf("%2F") >= 0)
	      || (normalized.indexOf("%2E") >= 0)
	      || (normalized.indexOf("%5C") >= 0)
	      || (normalized.indexOf("%2f") >= 0)
	      || (normalized.indexOf("%2e") >= 0)
	      || (normalized.indexOf("%5c") >= 0)) {
	      return null;
	    }
	    
	    if (normalized.equals("/."))
	        return "/";
	 
	    // Normalize the slashes and add leading slash if necessary
	 	if (normalized.indexOf('\\') >= 0)
	 		normalized = normalized.replace('\\', '/');
 		if (!normalized.startsWith("/"))
 			normalized = "/" + normalized;
 	
 		// Resolve occurrences of "//" in the normalized path
 		while(true) {
 			int index = normalized.indexOf("//");
 			if (index < 0) {
 				break;
 			}
 			normalized = normalized.substring(0,  index) + 
 			normalized.substring(index + 1);
 		}
 		
 		while (true) {
			int index = normalized.indexOf("/./");
			 if (index < 0)
		        break;
		      normalized = normalized.substring(0, index) +
		        normalized.substring(index + 2);
		}
 		
 		// Resolve occurrences of "/../" in the normalized path
 		  while (true) {
 		      int index = normalized.indexOf("/../");
 		      if (index < 0)
 		        break;
 		      if (index == 0)
 		    	  return null;
 		     int index2 = normalized.lastIndexOf('/', index - 1);
 		      normalized = normalized.substring(0, index2) +
 		    	        normalized.substring(index + 3);
 		  }
 		// Declare occurrences of "/..." (three or more dots) to be invalid
	    // (on some Windows platforms this walks the directory tree!!!)
	    if (normalized.indexOf("/...") >= 0)
	      return (null);

	    // Return the normalized path that we have completed
	    return (normalized);
	}

	private synchronized Socket await() {
		while (!available) {
			try {
//				System.out.println(Thread.currentThread().getName() + "await .. wait");
				wait();
			} catch (InterruptedException e) {
			}
		}
		Socket socket = this.socket;
		available = false;
//		System.out.println(Thread.currentThread().getName() + "await..notifyAll");
		notifyAll();
		return socket;
	}
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + "satrt...");
		while(!stopped) {
			Socket socket = await();
			if (socket == null ) {
				continue;
			}
			
			process(socket);
			
			connector.recycle(this);
		}
	}

	public boolean isAvailable() {
		return available;
	}
	
}
