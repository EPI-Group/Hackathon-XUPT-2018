package com.mec.pymont.interfaces;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;

public interface Valve {
	String getInfo();
	void invoke(HttpRequest request, HttpResponse response, ValveContext valveContext) throws Exception;
}
