package com.mec.container.filter;

import java.util.HashMap;
import java.util.Map;

public final class FilterDef {

	/*
	 * the description of the filter.
	 */
	
//	private String descrition = null;
//	public String getDescrition() {
//		return descrition;
//	}
//
//	public void setDescrition(String descrition) {
//		this.descrition = descrition;
//	}
	
	/*
	 * the display name of this filter.Ӧ������
	 */
	private String displayName = null;
	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	/*
	 * the fully qualified name of java class that implements this
	 * filter.
	 */
	private String filterClass = null;
	public String getFilterClass() {
		return filterClass;
	}
	public void setFilterClass(String filterClass) {
		this.filterClass = filterClass;
	}
	
	/*
	 * The name of this filter, which must be unique among the filters
	 * defined for a particular web application.
	 */
	private String filterName = null;
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	
//	private String largeIcon = null;
//	public String getLargeIcon() {
//		return largeIcon;
//	}
//	public void setLargeIcon(String largeIcon) {
//		this.largeIcon = largeIcon;
//	}
//	
//	private String smallIcon = null;
//	public String getSmallIcon() {
//		return smallIcon;
//	}
//	public void setSmallIcon(String smallIcon) {
//		this.smallIcon = smallIcon;
//	}

	private Map<String, String> parameters = new HashMap<String, String>();
	public Map<String, String> getParameters() {
		return parameters;
	}
	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}
	
	public void addInitParameter(String name, String value) {
		parameters.put(name, value);
	}

	@Override
	public String toString() {
		return "FilterDef [displayName=" + displayName + ", filterClass=" + filterClass
				+ ", filterName=" + filterName + "]";
	}
}
