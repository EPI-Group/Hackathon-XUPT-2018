package com.mec.pymont.interfaces;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

public interface Wrapper extends Container{
	public Servlet allocate() throws ServletException;
	public void load();
}
