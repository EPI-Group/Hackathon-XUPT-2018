package com.mec.connector;

import java.util.Stack;

import com.mec.pymont.interfaces.Lifecycle;

public class Processors implements Lifecycle{
	private Stack<Processor> processorList = new Stack<>();
	private Connector connector;
	private volatile int currCount = 0;
	private final int initCount = 4;
	private final int addCount = 2;
	private final int maxCount = 10;
	
	private final int waitTime = 2000;
	
	public Processors(Connector connector) {
		this.connector = connector;
	}
	
	public Processor getProcessor() {
		int addResult = 0;
		while (processorList.isEmpty()) {
			if(currCount < maxCount) {
				synchronized (Processors.class) {
					if(currCount < maxCount) {
						addResult = addProcessors(addCount);
					}
				}
				if (addResult < 0) {
					try {
						Thread.sleep(waitTime);
					} catch (InterruptedException e) {
					}
				}
			}
		}
		
		System.out.println("is not Empty");
		return processorList.pop();
	}

	private synchronized int addProcessors(int num) {
		int addNum = num;
		if (currCount > maxCount) {
//			System.out.println("is full !!!////////////////////");
			return -1;
		}
		if (maxCount < currCount + addCount) {
			addNum = maxCount - currCount;
			if (addNum <= 0) {
				return addNum;
			}
		}
		
		for(int i = 0; i < addNum; i++) {
			Processor processor = new Processor(connector);
			Thread thread = new Thread(processor);
			thread.start();
			currCount++;
//			System.out.println("currCount:[ " + currCount + ":"+ maxCount +" ]--------");
			processorList.add(processor);
		}
		return addNum;
	}
	
	public void recycleProcessor(Processor processor) {
		processorList.push(processor);
	}
	
	@Override
	public void start() {
		addProcessors(initCount);
		// TODO Auto-generated method stub
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}
}
