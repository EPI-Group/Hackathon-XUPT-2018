package com.mec.container;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.Servlet;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;
import com.mec.container.filter.ApplicationFilterChain;
import com.mec.container.filter.ApplicationFilterConfig;
import com.mec.container.filter.FilterDef;
import com.mec.container.filter.FilterMap;
import com.mec.pymont.interfaces.Contained;
import com.mec.pymont.interfaces.Container;
import com.mec.pymont.interfaces.Context;
import com.mec.pymont.interfaces.Valve;
import com.mec.pymont.interfaces.ValveContext;
import com.mec.pymont.interfaces.Wrapper;
import com.mec.util.XMLReader;

public class SimpleWrapperValve implements Valve,Contained{

	private Container container;
	
	@Override
	public String getInfo() {
		return "SimpleWrapperValve...";
	}

	@Override
	public void invoke(HttpRequest request, HttpResponse response, ValveContext valveContext) throws Exception {
		// TODO Auto-generated method stub
		Servlet servlet = ((Wrapper)container).allocate();
		ApplicationFilterChain chain = creatFilterChain();

		chain.doFilter(request, response);
		response.finishResponese();
		SimpleContextMapper mapper = new SimpleContextMapper();
		mapper.map(request, true);
		if (chain != null) {
			chain.release();
		}
	}

	@Override
	public Container getContainer() {
		return container;
	}

	@Override
	public void setContainer(Container container) {
		this.container = container;
	}
	
	private ApplicationFilterChain creatFilterChain() {
		ApplicationFilterChain chain = null;
		ArrayList<FilterDef> filterDefList = new ArrayList<>();
		HashMap<String, FilterMap> filterMap = new HashMap<String, FilterMap>();
		ArrayList<Filter> filterList = new ArrayList<>();
		XMLReader.parseFiltersMaps(filterDefList, filterMap);
		for(int i = 0; i < filterDefList.size(); i++) {
			if (trueUrlFilter(filterMap, filterDefList.get(i))) {
				ApplicationFilterConfig config = new ApplicationFilterConfig(((Context)((SimpleWapper)container).getParent()),
						filterDefList.get(i));
				Filter filter = config.getFilter();
				if (filter != null) {
					filterList.add(filter);
				}
			}
		}
		chain = new ApplicationFilterChain(filterList, ((SimpleWapper)container).getInstance());
		return chain;
	}
	
	private boolean trueUrlFilter(HashMap<String, FilterMap> filterMap, FilterDef filterDef) {
		
		//TODO ·��ƥ����container����ƥ���������⣬Ӧ��container����·��
		try {
			String urlPattern = filterMap.get(filterDef.getFilterName()).getUrlPattern();
			if ("/*".equals(urlPattern))
				return true;
			String containerName = ((SimpleWapper)container).getName();
			String filterPatterName = urlPattern.substring(urlPattern.lastIndexOf("/")+1);
			return containerName.equals(filterPatterName);
		} catch (RuntimeException e) {
			return false;
		}
		
	}
}
