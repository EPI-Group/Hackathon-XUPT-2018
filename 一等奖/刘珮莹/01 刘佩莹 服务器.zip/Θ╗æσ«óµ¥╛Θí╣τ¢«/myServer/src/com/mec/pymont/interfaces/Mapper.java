package com.mec.pymont.interfaces;

import com.mec.connector.http.HttpRequest;

public interface Mapper {
	Container getContainer();
	String getProtocol();
	Container map(HttpRequest request, boolean update);
	void setContainer(Container container);
	void setProtocol(String protocol);
}
