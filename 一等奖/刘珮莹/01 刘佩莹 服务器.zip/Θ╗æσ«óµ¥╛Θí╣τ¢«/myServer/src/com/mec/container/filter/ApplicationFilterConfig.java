package com.mec.container.filter;

import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import com.mec.pymont.interfaces.Context;

public class ApplicationFilterConfig implements FilterConfig{

	private Context context;
	private FilterDef filterDef;
	private Filter filter;
	
	public ApplicationFilterConfig(Context context, FilterDef filterDef) {
		this.context = context;
		this.filterDef = filterDef;
	}
	
	public ApplicationFilterConfig(Context context, FilterMap filterMap) {
		this.context = context;
	}
	
	@Override
	public String getFilterName() {
		return filterDef.getFilterName();
	}

	@Override
	public String getInitParameter(String name) {
		return filterDef.getParameters().get(name);
	}

	@Override
	public Enumeration getInitParameterNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ServletContext getServletContext() {
		// TODO Auto-generated method stub
		return null;
	}

	public Filter getFilter() {
		if (filter == null) {
			String filterClass = filterDef.getFilterClass();
			try {
				Class<?> clazz = Class.forName(filterClass);
				Object obj = clazz.newInstance();
				if (obj instanceof Filter) {
					filter = (Filter)obj;
				}
				filter.init(this);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (ServletException e) {
				e.printStackTrace();
			} 
		}
		
		return filter;
	}
}
