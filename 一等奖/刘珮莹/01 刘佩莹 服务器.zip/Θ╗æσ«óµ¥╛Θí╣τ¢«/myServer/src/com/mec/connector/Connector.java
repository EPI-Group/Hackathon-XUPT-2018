package com.mec.connector;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import com.mec.pymont.interfaces.Container;
import com.mec.pymont.interfaces.Lifecycle;

public class Connector implements Runnable,Lifecycle{
	private ServerSocket serverSocket = null;
	public static final String WEB_ROOT = 
			System.getProperty("user.dir") + File.separatorChar + "webroot";
	private boolean start = false;
	private Processors processors = null;
	//servlet����
	private Container container = null;
	
	public Container getContainer() {
		return container;
	}

	public void setContainer(Container container) {
		this.container = container;
	}

	private Processor createProcessor() {
		//TODO
		return processors.getProcessor();
	}
	
	public void recycle(Processor processor) {
		processors.recycleProcessor(processor);
	}
	
	@Override
	public void run() {
		while(start) {
			if (serverSocket == null) {
				return;
			}
			try {
				System.out.println("--accept");
				Socket socket = serverSocket.accept();
				Processor processor = createProcessor();
				System.out.println("assign");
				processor.assign(socket);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void start() {
		start = true;
		try {
			serverSocket = new ServerSocket(Constants.PORT, 1, InetAddress.getByName("127.0.0.1"));
			Thread thread = new Thread(this);
			thread.start();
			
			processors = new Processors(this);
			processors.start();
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}
}
/*

Socket socket = null;
InputStream input = null;
OutputStream output = null;

while(start) {
	try {
		socket = serverSocket.accept();
		input = socket.getInputStream();
		output = socket.getOutputStream();
		Request request = new Request(input);
		request.parseInput();
		
		Response response = new Response(request, output);
		response.sendStaticResource();
		
		socket.close();
	} catch (IOException e) {
		e.printStackTrace();
	}
}
*/