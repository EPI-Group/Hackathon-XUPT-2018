package com.mec.pymont.interfaces;

import javax.servlet.ServletContext;

import com.mec.connector.http.HttpRequest;

public interface Context extends Container{
	ServletContext getServletContext();
	Container map(HttpRequest request, boolean update);
	MyManager getManager();
}
