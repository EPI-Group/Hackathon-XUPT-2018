package com.mec.connector;

import java.io.IOException;
import java.io.InputStream;
	
public class Request {
	private InputStream input = null;
	private String uri = null;
	
	public Request(InputStream input) {
		this.input = input;
	}
	
	public void parseInput() {
		try {
			byte[] buffer = new byte[2 * 1024];
			String result = "";
			int len = input.read(buffer);
			for (int i = 0; i < len; i++) {
				result += (char)buffer[i];
			}
			System.out.println(result);
			uri = paseUri(result);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String paseUri(String request) {
		int space1 = request.indexOf(' ');
		if (space1 > 0) {
			int space2 = request.indexOf(' ', space1+1);
			if (space2 > 0) {
				return (request.substring(space1 + 1, space2)).replace('/', '\\');
			}
		}
		return null;
	}

	public String getUri() {
		return uri;
	}
}
