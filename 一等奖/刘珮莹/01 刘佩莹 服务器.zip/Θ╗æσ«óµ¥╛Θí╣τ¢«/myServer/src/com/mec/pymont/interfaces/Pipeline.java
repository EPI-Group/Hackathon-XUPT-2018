package com.mec.pymont.interfaces;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;

public interface Pipeline {
	Valve getBasic();
	void setBasic(Valve valve);
	void addValve(Valve valve);
	Valve[] getValves();
	void invoke(HttpRequest request, HttpResponse response) throws Exception;
	void removeValve(Valve valve);
}
