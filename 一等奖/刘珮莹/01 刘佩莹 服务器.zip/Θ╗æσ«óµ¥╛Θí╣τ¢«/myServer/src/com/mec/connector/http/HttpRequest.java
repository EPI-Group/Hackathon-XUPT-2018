package com.mec.connector.http;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.Socket;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.mec.pymont.interfaces.Container;
import com.mec.pymont.interfaces.Wrapper;

public class HttpRequest extends HttpRequestBase implements HttpServletRequest{

	private InputStream input;
	
	private Wrapper wrapper;
	private String contentType;
	private int contentLength;
	private InetAddress inetAddress;
	private String method;
	private String protocol;
	private String queryString;
	private String requestURI;
	private String serverName;
	private int serverPort;
	private Socket socket;

	protected HashMap attributes = new HashMap();
	protected String authorization = null;
	protected String contextPath = "";
	protected ArrayList cookies = new ArrayList();
	protected static ArrayList empty = new ArrayList();
	
	protected HashMap headers = new HashMap();
	protected boolean paresed = false;
	protected String pathInfo = null;
	protected BufferedReader reader = null;
	protected ServletInputStream stream = null;

	public void setWrapper(Wrapper wrapper) {
		this.wrapper = wrapper;
	}
	
	public Container getWrapper() {
		return wrapper;
	}
	
	public HttpRequest(InputStream input) {
		this.input = input;
	}
	
	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}
	
	public void setMethod(String method) {
		this.method = method;
	}
	
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	
	public void setRequestURI(String requestURI) {
		this.requestURI = requestURI;
	}
	
	public void addHeader(String name, String value) {
		name = name.toLowerCase();
		synchronized (headers) {
			ArrayList values = (ArrayList) headers.get(name);
			if (values == null) {
				values = new ArrayList();
				headers.put(name, values);
			}
			values.add(value);
		}
	}
	
	public void addCookie(Cookie cookie) {
		synchronized (cookie) {
			cookies.add(cookie);
		}
	}
	
	public void setContentLength(int length) {
		this.contentLength = length;
	}
	
	public void setContentType(String type) {
		  this.contentType = type;
	}

	@Override
	public String getRequestURI() {
		return requestURI;
	}
	
	@Override
	public String getContextPath() {
		return contextPath;
	}
}
