package com.mec.pymont.interfaces;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;

public interface Container {
	void invoke(HttpRequest request, HttpResponse response);
	String getName();
	void setParent(Container container);
	void addChild(Container child);
}
