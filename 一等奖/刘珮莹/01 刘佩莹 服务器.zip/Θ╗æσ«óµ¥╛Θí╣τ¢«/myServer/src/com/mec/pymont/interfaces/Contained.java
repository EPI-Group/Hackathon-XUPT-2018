package com.mec.pymont.interfaces;

public interface Contained {
	Container getContainer();
	void setContainer(Container container);
}
