package com.mec.pymont.interfaces;

public interface Lifecycle {
	void start();
	void stop();
}
