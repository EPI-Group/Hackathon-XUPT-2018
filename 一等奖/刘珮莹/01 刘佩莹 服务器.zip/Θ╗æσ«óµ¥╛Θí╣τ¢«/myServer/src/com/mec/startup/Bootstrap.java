package com.mec.startup;


import org.apache.catalina.Loader;

import com.mec.connector.Connector;
import com.mec.container.SimpleContext;
import com.mec.container.SimpleContextMapper;
import com.mec.container.SimpleWapper;
import com.mec.container.loaders.SimpleLoader;
import com.mec.pymont.interfaces.Mapper;

public class Bootstrap {
	
	public static void main(String[] args) {
		Connector server = new Connector();
		SimpleWapper wrapper = new SimpleWapper();
		Loader loader = new SimpleLoader();
		wrapper.setLoader(loader);
		wrapper.setServletClass("PrimitiveServlet");

		SimpleContext context = new SimpleContext();
		context.addChild(wrapper);
		
		Mapper mapper = new SimpleContextMapper();
		mapper.setProtocol("HTTP/1.1");
		context.addMapper(mapper);
		context.addServletMapping("/PrimitiveServlet", "PrimitiveServlet");
		
		server.setContainer(context);
		server.start();
	}
	
}
