package com.mec.container;

import java.util.HashMap;

import javax.servlet.ServletContext;

import org.apache.catalina.Loader;
import org.apache.catalina.Logger;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;
import com.mec.pymont.interfaces.Container;
import com.mec.pymont.interfaces.Context;
import com.mec.pymont.interfaces.Lifecycle;
import com.mec.pymont.interfaces.Mapper;
import com.mec.pymont.interfaces.MyManager;
import com.mec.pymont.interfaces.Pipeline;
import com.mec.pymont.interfaces.Valve;


public class SimpleContext implements Context, Pipeline, Lifecycle{

	protected HashMap children = new HashMap();
	private Loader loader = null;
	private Logger logger = null;
	protected Mapper mapper = null;
	protected HashMap mappers = new HashMap();
	private HashMap servletMappings = new HashMap();
	private Container parent = null;
	protected boolean started = false;
	private String name;
	private MyManager manager = null;
	
	protected SimplePipeline pipeline = new SimplePipeline(this);
	
	public SimpleContext() {
		pipeline.setBasic(new SimpleContextValve());
	}

	@Override
	public void invoke(HttpRequest request, HttpResponse response) {
		// TODO Auto-generated method stub
		try {
			pipeline.invoke(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void addChild(Container container) {
		container.setParent(this);
		children.put(container.getName(), container);
	}

	public void addServletMapping(String pattern, String name) {
		synchronized (servletMappings) {
			servletMappings.put(pattern, name);
		}
	}
	
	public String findServletMapping(String pattern) {
		synchronized (servletMappings) {
			return (String) servletMappings.get(pattern);
		}
	}
	
	public Container findChild(String name) {
		if (name == null)
			return null;
		synchronized (children) {
			return (Container) children.get(name);
		}
	}
	
	public void addMapper(Mapper mapper) {
		synchronized (mappers) {
			if (mappers.get(mapper.getProtocol()) != null) {
				throw new IllegalArgumentException("addMapper:  Protocol '" +
				          mapper.getProtocol() + "' is not unique");
			}
			mapper.setContainer(this);
			mappers.put(mapper.getProtocol(), mapper);
			if (mappers.size() == 1)
				this.mapper = mapper;
			else
				this.mapper = null;
		}
	}
	
	public Container map(HttpRequest request, boolean update) {
		System.out.println(request.getProtocol()+"pro");
		Mapper mapper = findMapper(request.getProtocol());
		if (mapper == null)
			return null;
		return mapper.map(request, update);
	}
	
	public Mapper findMapper(String protocol) {
		if (mapper != null) {
			return mapper;
		} else {
			synchronized (mappers) {
				return (Mapper) mappers.get(protocol);
			}
		}
	}
	
	@Override
	public ServletContext getServletContext() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Valve getBasic() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setBasic(Valve valve) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addValve(Valve valve) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Valve[] getValves() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeValve(Valve valve) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public void setParent(Container parent) {
		// TODO Auto-generated method stub
		this.parent = parent;
	}

	@Override
	public MyManager getManager() {
		// TODO Auto-generated method stub
		return manager;
	}

}
