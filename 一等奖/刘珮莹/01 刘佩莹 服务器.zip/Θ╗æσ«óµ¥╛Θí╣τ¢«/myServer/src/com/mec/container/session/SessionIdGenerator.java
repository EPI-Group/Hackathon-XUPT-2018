package com.mec.container.session;

import java.util.Random;

public class SessionIdGenerator {
	private int sessionIdLength = 20;
	private String jvmRoute = System.getProperty("java.version", "not specified");
	public String generateSessionId() {
		byte random[] = new byte[16];
		
		StringBuilder buffer = new StringBuilder();
		int resultLenBytes = 0;
		
		while(resultLenBytes < sessionIdLength) {
			getRandomBytes(random);
			for (int j = 0; j < random.length && resultLenBytes < sessionIdLength; j++) {
				byte b1 = (byte)((random[j] & 0xf0)>>4);
				byte b2 = (byte)(random[j] & 0x0f);
				if (b1 < 10)
					buffer.append((char)('0' + b1));
				else 
					buffer.append((char)('A' + b1 - 10));
				if (b2 < 10)
					buffer.append((char)('0' + b2));
				else 
					buffer.append((char)('A' + b2 - 10));
				resultLenBytes++;
			}
		}
		if (jvmRoute != null && jvmRoute.length() > 0) {
			buffer.append('.').append(jvmRoute);
		}
		
		return buffer.toString();
	}

	private void getRandomBytes(byte[] random) {
		Random r = new Random();
		for (int i = 0; i < random.length; i++) {
			random[i] = Byte.valueOf(String.valueOf(r.nextInt(Byte.MAX_VALUE)));
		}
	}

}
