package com.mec.pymont.interfaces;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;

public interface ValveContext {
	String getInfo();
	void invokeNext(HttpRequest request, HttpResponse response) throws Exception;
}
