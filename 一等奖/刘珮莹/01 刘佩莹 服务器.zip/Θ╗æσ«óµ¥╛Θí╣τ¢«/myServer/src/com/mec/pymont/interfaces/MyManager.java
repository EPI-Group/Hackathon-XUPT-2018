package com.mec.pymont.interfaces;

import java.beans.PropertyChangeListener;
import java.io.IOException;

import org.apache.catalina.Container;
import org.apache.catalina.DefaultContext;
import org.apache.catalina.Manager;
import org.apache.catalina.Session;

public interface MyManager extends Manager{

	public void add(Session session);

	public void addPropertyChangeListener(PropertyChangeListener listener);

	public Session createEmptySession();

	public Session createSession(String requestSessionId);

	public Session findSession(String sessionId);

	public Session[] findSessions();

	public Container getContainer();

	public DefaultContext getDefaultContext();

	public boolean getDistributable();
	
	public String getInfo();

	public int getMaxInactiveInterval();

	public void load() throws ClassNotFoundException, IOException;

	public void remove(Session session);

	public void removePropertyChangeListener(PropertyChangeListener listener);

	public void setContainer(Container container);

	public void setDefaultContext(DefaultContext context);

	public void setDistributable(boolean arg0);

	public void setMaxInactiveInterval(int arg0);

	public void unload() throws IOException;
}
