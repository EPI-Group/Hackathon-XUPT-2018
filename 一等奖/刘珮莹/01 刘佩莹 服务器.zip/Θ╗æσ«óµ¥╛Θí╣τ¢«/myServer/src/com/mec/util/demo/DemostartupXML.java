package com.mec.util.demo;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;

import com.mec.util.XMLReader;

public class DemostartupXML {

	public static void main(String[] args) {
		Document xml = XMLReader.parseXML("/startup.xml");
		NodeList connectorList = xml.getElementsByTagName("connector");
		for (int i = 0; i < connectorList.getLength(); i++) {
			Element connector = (Element) connectorList.item(i);
			NamedNodeMap connectorAttrMap = connector.getAttributes();
		}
	}
}
