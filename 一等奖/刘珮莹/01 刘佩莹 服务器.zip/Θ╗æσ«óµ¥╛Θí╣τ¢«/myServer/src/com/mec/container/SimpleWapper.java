package com.mec.container;

import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.catalina.Loader;
import org.apache.catalina.util.Enumerator;

import com.mec.connector.http.HttpRequest;
import com.mec.connector.http.HttpResponse;
import com.mec.pymont.interfaces.Container;
import com.mec.pymont.interfaces.Context;
import com.mec.pymont.interfaces.Lifecycle;
import com.mec.pymont.interfaces.Pipeline;
import com.mec.pymont.interfaces.Valve;
import com.mec.pymont.interfaces.Wrapper;

public class SimpleWapper implements Wrapper, Pipeline, ServletConfig, Lifecycle{
	
	protected Container parent = null;
	private Servlet instance = null;
	private Loader loader;
	private String servletClass;
	private String name;
	private SimplePipeline pipeline = new SimplePipeline(this);
	private HashMap<String, String> parameters = new HashMap<String, String>();
	
	public SimpleWapper() {
		pipeline.setBasic(new SimpleWrapperValve());
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Container getParent() {
		return parent;
	}
	
	public void setParent(Container parent) {
		this.parent = parent;
	}

	public Servlet getInstance() {
		return instance;
	}
	
	public void setServletClass(String servletClass) {
		this.servletClass = servletClass;
		//û�ص����õĻ�Ĭ��Ϊservletclass
		if (name == null) {
			setName(servletClass);
		}
	}

	public void setLoader(Loader loader) {
		this.loader = loader;
	}

	@Override
	public void invoke(HttpRequest request, HttpResponse response) {
		try {
			pipeline.invoke(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Valve getBasic() {
		return pipeline.getBasic();
	}

	@Override
	public void setBasic(Valve valve) {
		pipeline.setBasic(valve);
	}

	@Override
	public void addValve(Valve valve) {
		pipeline.addValve(valve);
	}

	@Override
	public Valve[] getValves() {
		return pipeline.getValves();
	}

	@Override
	public void removeValve(Valve valve) {
		pipeline.removeValve(valve);
	}

	@Override
	public Servlet allocate() throws ServletException {
		if (instance == null) {
			try {
				instance = loadServlet();
			}
			catch (ServletException e) {
		        throw e;
			}
			catch (Throwable e) {
			  throw new ServletException("Cannot allocate a servlet instance", e);
			}
		}
		return instance;
	}

	private Servlet loadServlet() throws ServletException {
		System.out.println("loadServlet.......");
		if (instance != null) {
			return instance;
		}
		
		Servlet servlet = null;
		String actualclass = servletClass;
		if (actualclass == null) {
			throw new ServletException("servlet class has not been specified");
		}
		ClassLoader classLoader = loader.getClassLoader();
		setName(actualclass);
		
		Class<?> classclass = null;
		try {
			if (classLoader != null) {
				classclass = classLoader.loadClass(actualclass);
				
			}
		} catch (ClassNotFoundException e) {
			throw new ServletException("Servlet class not found");
		}
		
		try {
			servlet = (Servlet) classclass.newInstance();
		} 
		catch (Throwable e) {
		    throw new ServletException("Failed to instantiate servlet");
		}
		
		try {
			  servlet.init(this);
		}
		catch (Throwable f) {
		  throw new ServletException("Failed initialize servlet.");
		}
		
		return servlet;
	}

	public String findInitParameter(String name) {
		synchronized (parameters) {
			return (String) parameters.get(name);
		}
	}
	
	public void addInitParameter(String name, String value) {
		synchronized (parameters) {
			parameters.put(name, value);
		}
		System.out.println("addInitParameter: " + name);
	}
	
	@Override
	public void load() {
		try {
			allocate();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String getInitParameter(String name) {
		return findInitParameter(name);
	}

	@Override
	public Enumeration getInitParameterNames() {
		synchronized (parameters) {
			return new Enumerator(parameters.keySet());
		}
	}

	@Override
	public ServletContext getServletContext() {
		if (parent == null) {
			return null;
		} else if (!(parent instanceof Context)) {
			return null;
		}
		
		return ((Context)parent).getServletContext();
	}

	@Override
	public String getServletName() {
		return getName();
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		if (instance != null) {
			instance.destroy();
		}
	}

	@Override
	public void addChild(Container child) {
		// TODO Auto-generated method stub
		
	}
 }
