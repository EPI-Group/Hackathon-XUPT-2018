package com.mec.container.filter;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class ApplicationFilterChain implements FilterChain{

	private Servlet servlet = null;
	private ArrayList<Filter> filterList = new ArrayList<>();
	
	
	public ApplicationFilterChain(ArrayList<Filter> filterList, Servlet servlet) {
		this.filterList = filterList;
		this.servlet = servlet;
	}
	
	public ApplicationFilterChain(ArrayList<Filter> filterList) {
		this.filterList = filterList;
	}

	private int index = 0;
	
	@Override
	public void doFilter(ServletRequest req, ServletResponse res) throws IOException, ServletException {
		int pos = index;
		index++;
		if (pos < filterList.size()) {
			filterList.get(pos).doFilter(req, res, this);
		}
		if (pos == filterList.size()-1 && servlet != null) {
			servlet.service(req, res);
		}
	}
	
	public void release() {
		servlet = null;
		for (int i = 0; i < filterList.size(); i++) {
			filterList.get(i).destroy();
		}
		filterList.clear();
		index = 0;
	}
}
