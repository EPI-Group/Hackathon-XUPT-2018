package ex01.pyrmont;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.ServletException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.mec.container.SimpleWapper;
import com.mec.container.filter.ApplicationFilterChain;
import com.mec.container.filter.ApplicationFilterConfig;
import com.mec.container.filter.FilterDef;
import com.mec.pymont.interfaces.Context;
import com.mec.util.XMLReader;

public class DemoXMLReader {
	public static void main(String[] args) {
//		ApplicationFilterChain chain = new DemoXMLReader().creatFilterChain();
//		try {
//			chain.doFilter(null, null);
//		} catch (IOException | ServletException e) {
//			e.printStackTrace();
//		}
		System.out.println(System.getProperty("user.dir")+"\\src\\ex01\\pyrmont");
	}
	
	private ApplicationFilterChain creatFilterChain() {
		ApplicationFilterChain chain = null;
		ArrayList<FilterDef> filterDefList = new ArrayList<>();
		Document document = XMLReader.parseXML("/WEB-INF/web.xml");
		NodeList filters = document.getElementsByTagName("filter");
		
		XMLReader.parseFilters(filters, filterDefList);
		ArrayList<Filter> filterList = new ArrayList<>();
		
		for(int i = 0; i < filterDefList.size(); i++) {
			//TODO
			ApplicationFilterConfig config = new ApplicationFilterConfig(null,
					filterDefList.get(i));
			Filter filter = config.getFilter();
			if (filter != null) {
				filterList.add(filter);
			}
		}
		chain = new ApplicationFilterChain(filterList, null);
		return chain;
	}
	
	
}
