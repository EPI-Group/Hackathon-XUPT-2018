// pages/first-page/first-page.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  onTap1: function(){
       wx.navigateTo({
         url: '../second-page/form/form',
       })
  },
     onTap2: function () {
          wx.navigateTo({
               url: '../backhome/post',
          })
     },
     onTap3: function () {
          wx.navigateTo({
               url: '../second-page/welcome/welcome',
          })
     },
     onTap4: function () {
          wx.navigateTo({
               url: '../second-page/love/love',
          })
     }
})