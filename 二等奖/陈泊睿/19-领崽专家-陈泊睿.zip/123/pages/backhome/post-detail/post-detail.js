var postsData = require("../data/posts-data.js")

Page({
  data:{

  },//借助data作为数据中转

  onLoad: function(option) {
    var postId = option.id;
    this.data.currentPostId = postId;
    var postData = postsData.postList[postId];
    this.setData({
      postData:postData,
    })
    
    
    var postsCollected = wx.getStorageSync("posts_collected")
    if(postsCollected){
    var collected = postsCollected[postId]
    this.setData({
      collected:postsCollected
    })
     
    }
    else{
      var postsCollected = {};
      postsCollected[postId] = false;
      wx.setStorageSync("posts_collected", postsCollected)
     
    }
  },
  onCollectionTap:function(event){
   var postsCollected = wx.getStorageSync("posts_collected")
   var postCollected = postsCollected[this.data.currentPostId];
  
   //收藏与未收藏之间的切换
   postCollected = !postCollected;
   postsCollected[this.data.currentPostId] = postCollected;
   
   //更新了文章是否收藏的缓存值
   wx.setStorageSync("posts_collected",postsCollected)
   
   //更新数据绑定变量从而更新图片
   this.setData({
     collected:postCollected,
   })
  },


})   

      
       
      

       
     
   
   
 