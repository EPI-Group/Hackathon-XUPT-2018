var post_content = [{
    title: "万博宠物医院",
  content: "地址：新城区南二环兴庆桥十字西北角（交大南门）",
    image: "/images/post-imges/1_1.jpg ",
     image1: "/images/post-imges/2_1.jpg ",
    author: "营业时间：周一至周天 09:00-20:30",
    date: "领养 | 绝育 | 体检 | 疫苗 | 美容",
    
  
   
   
    postId: 0,
  },
  {
    title: "你我它动物医院（仁爱分院）",
    content: "地址：高新区西安丈八北路枫韵蓝湾西门（科技路西口向北200米）",
       image: "/images/post-imges/1_2.jpg",
       image1: "/images/post-imges/2_2.jpg ",
    author: "营业时间：周一至周天 全天",
    date: "领养 | 绝育 | 体检 | 疫苗 |夜间看护",
    
    postId: 1,
  },
  {
    title: "张琳动物医院",
    content: "地址：新城区北辰东路华远海蓝城五期西门（靠近热力公司）",
       image: "/images/post-imges/1_3.jpg ",
       image1: "/images/post-imges/2_3.jpg ",
    author: "营业时间：周一至周天 09:00-21:30",
    date: "领养 | 绝育 | 体检 | 疫苗 | 助产|待产看护",
   
    postId: 2,
  },
  {
    title: "西唯动物医院",
    content: "地址：雁塔区华城万象一期底商17-10101",
       image: "/images/post-imges/1_4.jpg",
       image1: "/images/post-imges/2_4.jpg ",
    author: "营业时间：周一至周天 08:00-21:30",
    date: "领养 | 绝育 | 体检 | 疫苗 | 寄样",
   
    postId: 3,
  },
  {
    title: "振明宠物医院",
    content: "地址：雁塔区曲江官邸3711号商铺",
       image: "/images/post-imges/1_2.jpg",
       image1: "/images/post-imges/2_2.jpg ",
    author: "营业时间：周一至周天 09:00-21:30",
    date: "领养 | 绝育 | 体检 | 疫苗 |夜间看护",
   
    postId: 4,
  },

]
module.exports = {
  postList: post_content
} //可多次指定变量通过此出口