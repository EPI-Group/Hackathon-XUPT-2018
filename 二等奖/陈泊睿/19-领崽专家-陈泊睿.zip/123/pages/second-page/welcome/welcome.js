Page({
  onPostTap: function () {
    wx.navigateTo({
      url: '../form/form',
    })
  },
  onTap: function () {
    wx.navigateTo({
      url: '../job/job',
    })
  },
})