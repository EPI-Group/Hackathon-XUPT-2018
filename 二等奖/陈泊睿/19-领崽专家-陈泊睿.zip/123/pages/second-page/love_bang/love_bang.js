Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  
    data: {
      listData: [
        { "code": "01", "text": "张三", "type":"救助流浪狗","cishu":"20"},
        { "code": "02", "text": "李四", "type": "救助流浪猫","cishu": "19"},
        { "code": "03", "text": "王二", "type": "捐赠狗粮","cishu": "17"},
        { "code": "04", "text": "后羿", "type": "救助流浪猫","cishu": "15"},
        { "code": "05", "text": "吕布", "type": "救助流浪狗","cishu": "13"},
        { "code": "06", "text": "貂蝉", "type": "救助流浪猫","cishu": "12"},
        { "code": "07", "text": "程咬金", "type": "义务劳动","cishu": "10"},
        { "code": "08", "text": "赵云", "type": "救助流浪猫","cishu": "10"},
        { "code": "09", "text": "李白", "type": "救助流浪狗","cishu": "9"},
        { "code": "10", "text": "韩星", "type": "救助流浪狗","cishu": "8"},
        { "code": "11", "text": "不知火舞", "type": "救助流浪狗","cishu": "7"},
        { "code": "12", "text": "郭嘉文", "type": "义工","cishu": "6"},
        { "code": "13", "text": "小胖子", "type": "义工","cishu": "5"},
        { "code": "14", "text": "马冬梅", "type": "义工","cishu": "4"},
        { "code": "15", "text": "秦宇豪", "type": "救助流浪狗","cishu": "2"}
      ]
    },
    onLoad: function () {
    console.log('onLoad')
  }

})
