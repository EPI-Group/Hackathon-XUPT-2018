Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (event) {
  },
  data: {
    listData: [{ "code": "01", "text": "张三", "type": "领养贵兵犬", },
      { "code": "02", "text": "李四", "type": "领养博美",  },
      { "code": "03", "text": "王二", "type": "捐赠泰迪",  },
      
    ]
  },
  onPostTap: function () {
    wx.navigateTo({
      url: '../love_bang/love_bang',
    })
  },
  onTap: function () {
    wx.navigateTo({
      url: '../give_form/give_form',
    })
  },
})